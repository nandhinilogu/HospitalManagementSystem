package bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class PatientDetails {

	public static boolean insertInPatientDetails(int patient_Id, String patient_Name, String address, String complaint,
			int amount_Paid, String contact_Number, String doctor_Name) {
		boolean status = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "");
			Statement st = con.createStatement();
			st.execute(
					"create table if not exists Inpatient(PatientId int PRIMARY KEY,PatientName varchar(20),Address varchar(20),Complaint varchar(20),AmountPaid int,ContactNumber varchar(20),DoctorName varchar(20))");
			st.execute("insert into Inpatient values('" + patient_Id + "','" + patient_Name + "','" + address + "','"
					+ complaint + "','" + amount_Paid + "','" + contact_Number + "','" + doctor_Name + "')");
			System.out.println("InPatient details are inserted successfully");
			ResultSet rs = st.executeQuery("select * from InPatient");
			status = rs.next();
		} catch (Exception e) {
			System.out.println(e);
		}

		return status;

	}

	public static boolean insertOutPatientDetails(int patient_Id, String patient_Name, String address, String complaint,
			int amount_Paid, String contact_Number, String doctor_Name) {
		boolean status = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "");
			Statement st = con.createStatement();
			st.execute(
					"create table if not exists Outpatient(PatientId int PRIMARY KEY,PatientName varchar(20),Address varchar(20),Complaint varchar(20),AmountPaid int,ContactNumber varchar(20),DoctorName varchar(20))");
			st.execute("insert into Outpatient values('" + patient_Id + "','" + patient_Name + "','" + address + "','"
					+ complaint + "','" + amount_Paid + "','" + contact_Number + "','" + doctor_Name + "')");
			System.out.println("OutPatient details are inserted successfully");
			ResultSet rs = st.executeQuery("select * from OutPatient");
			status = rs.next();
		} catch (Exception e) {
			System.out.println(e);
		}

		return status;
	}

	public static boolean inPatientDischargeDetails(int patient_Id) {
		boolean status=false;
		try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
		Statement st=con.createStatement();
		st.executeUpdate("delete from InPatient where PatientId=('"+patient_Id+"')");
		System.out.println("InPatient Discharged successfully");
		ResultSet rs=st.executeQuery("select * from InPatient");
		status=rs.next();
		}catch(Exception e) {
			System.out.println(e);
		}
		return status;
	}

}
