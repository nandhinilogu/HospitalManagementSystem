package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/viewPatientDetailsServlet")
public class viewInPatientDetailsServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from InPatient");
		out.println("<head><link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css' integrity='sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb' crossorigin='anonymous'>");
		out.println("<script src='https://code.jquery.com/jquery-3.2.1.slim.min.js' integrity='sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN' crossorigin='anonymous'></script>");
		out.println("<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js' integrity='sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh' crossorigin='anonymous'></script>");
		out.println("<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js' integrity='sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ' crossorigin='anonymous'></script>");
		out.println("<style>div{padding:50px;font-family:'Times New Roman';}</style></head>");
		out.println("<nav class='navbar navbar-expand-lg navbar-light' style='background-color:#e3f2fd;'>");
		out.println(" <a class='navbar-brand' href='PatientInformation.jsp'>HOME </a>");
		out.println("<button class='navbar-toggler' data-toggle='collapse' data-target='#navbarNavDropdown' aria-controls='navbarNavDropdown' aria-expanded='false' aria-label='Toggle navigation'>");
		out.println(" <span class='navbar-toggler-icon'></span>");
		out.println(" </button>");
		out.println(" <div class='collapse navbar-collapse' id='navbarNavDropdown'></div>");
		out.println(" <ul class='navbar-nav'>");
		out.println(" <li class='nav-item active'>");
		out.println("<script type='text/javascript'>");
        out.println("function preventBack() { window.history.forward(); }");
        out.println("setTimeout('preventBack()', 0);");
        out.println("window.onunload = function () { null };");
        out.println("</script>");
		out.println("  <a class='nav-link' href='Login.html'>LOG OUT<span class='sr-only'></span></a>");
		out.println(" </li>");
		out.println("  </ul>");
	    out.println("</nav></head>");	
		out.print("<center><table border='1' style='color:blue'>");
		out.print("<tr><th>PatientId</th><th>PatientName</th><th>Address</th><th>Complaint</th><th>AmountPaid</th><th>ContactNumber</th><th>DoctorName</th></tr>");
		while(rs.next()) {
			out.print("<tr><td>"+rs.getInt(1)+"</td>");
			out.print("<td>"+rs.getString(2)+"</td>");
			out.print("<td>"+rs.getString(3)+"</td>");
			out.print("<td>"+rs.getString(4)+"</td>");
			out.print("<td>"+rs.getString(5)+"</td>");
			out.print("<td>"+rs.getString(6)+"</td>");
			out.print("<td>"+rs.getString(7)+"</td></tr>");
		}
		out.print("</table>");
		out.print("</center>");
		}catch(Exception e) {
			out.println(e);
		}
	}

}
