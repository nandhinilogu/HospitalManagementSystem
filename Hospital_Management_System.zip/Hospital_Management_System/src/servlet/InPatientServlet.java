package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import bean.PatientDetails;

@WebServlet("/InPatientServlet")
public class InPatientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String action=request.getParameter("action");
		int patient_Id=Integer.parseInt(request.getParameter("pid"));
		String patient_Name=request.getParameter("pname");
		String address=request.getParameter("address");
		String complaint=request.getParameter("complaint");
		int amount_Paid=Integer.parseInt(request.getParameter("amountpaid"));
		String contact_Number=request.getParameter("cnumber");
		String doctor_Name=request.getParameter("dname");
		if("Submit".equals(action)){
			if(PatientDetails.insertInPatientDetails(patient_Id,patient_Name,address,complaint,amount_Paid,contact_Number,doctor_Name)){
				out.println("<script type=\"text/javascript\">");
				   out.println("alert('Inpatient details inserted successfully');");
				   out.println("location='InPatient.html';");
				   out.println("</script>");
			
			}	
			else{
				out.println("<script type=\"text/javascript\">");
				   out.println("alert('Duplicate Entry for patient Id');");
				   out.println("location='InPatient.html';");
				   out.println("</script>");
			}
		}
	}

}
