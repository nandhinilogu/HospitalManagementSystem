package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import bean.Login;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String username=request.getParameter("user");
		String password=request.getParameter("pass");
		String action=request.getParameter("action");
		if("Login".equals(action)){
			
			if(Login.loginDetails(username,password)){
				response.sendRedirect("PatientInformation.jsp");
			}
			else
			{    
				final JPanel panel=new JPanel();
			    JOptionPane.showMessageDialog(panel,"Enter a Valid Username or Password\n If not registered click on New User and get registered","Error",JOptionPane.ERROR_MESSAGE);
				RequestDispatcher rd=request.getRequestDispatcher("Loginpage.html");
				rd.include(request, response);
			}
			
		}
	}

}
